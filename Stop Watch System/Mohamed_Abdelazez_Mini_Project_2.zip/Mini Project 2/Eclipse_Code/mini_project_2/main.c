#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>

/* Segment Enable */
#define SEGMENT_1 0x01
#define SEGMENT_2 0x02
#define SEGMENT_3 0x04
#define SEGMENT_4 0x08
#define SEGMENT_5 0x10
#define SEGMENT_6 0x20

/* Segment Values */
#define SEC_1 (second % 10)
#define	SEC_2 (second / 10)
#define	MIN_1 (minute % 10)
#define	MIN_2 (minute / 10)
#define	HR_1  (hour   % 10)
#define	HR_2  (hour   / 10)

unsigned char second = 0;
unsigned char minute = 0;
unsigned char hour = 0;

unsigned char flag = 0;

ISR(TIMER1_COMPA_vect)
{
	second++;
	if(second > 59)
	{
		second = 0;
		minute++;
		if(minute > 59)
		{
			minute = 0;
			hour++;
			if(hour > 99)
			{
				hour = 0;
				minute = 0;
				second = 0;
			}
		}
	}
}

ISR(INT0_vect)
{
	TCNT1  = 0;
	hour = 0;
	minute = 0;
	second = 0;
}

ISR(INT1_vect)
{
	TIMSK &= ~(1 << OCIE1A);                   				     /* disable Timer1 Compare A Interrupt */
	flag = 1;
}

ISR(INT2_vect)
{
	if(flag == 1)
	{
		TCNT1  = 0;
		TIMSK |= (1 << OCIE1A);                   				     /* Enable Timer1 Compare A Interrupt */
		flag = 0;
	}
}

void TIMER1_CTC_CONFIG(void)
{
	TCNT1  = 0;		              							     /* Set timer1 initial count to zero */
	OCR1A  = 1000;                      						 /* Set the Compare value to 1000*/
	TIMSK |= (1 << OCIE1A);                   				     /* Enable Timer1 Compare A Interrupt */
	TCCR1A = (1 << FOC1A);                                       /* Force Output Compare for Compare unit A */
	TCCR1B = (1 << WGM12) | (1 << CS10) | (1 << CS12);           /* CTC Mode, Prescaler value 1024*/
}

void IO_PINS_CONFIG(void)
{
	/* Push button 1 INT0 */
	DDRD  &= ~(1 << PD2);        /* input pin */
	PORTD |=  (1 << PD2);        /* internal pull up (-ve logic) */

	/* Push button 2 INT1 */
	DDRD  &= ~(1 << PD3);       /* input pin */

	/* Push button 3 INT2 */
	DDRB  &= ~(1 << PB2);       /* input pin */
	PORTB |=  (1 << PB2);       /* internal pull up (-ve logic) */

	/* Six 7-segments */
	DDRA  |= 0x3F;              /* Pin 0,1,2,3,4,5 output for 7-segments enable/disable */
	PORTA &= 0xC0;              /* Disable all 7-segments*/
	DDRC  |= 0x0F;              /* Pin 0,1,2,3 output */
	PORTC &= 0xF0;              /* initialize the 7-segment with value 0 by clear the first four bits in PORTC (-ve logic) */
}

void INT0_CONFIG(void)
{
	GICR  |=  (1 << INT0);       /* Interrupt request enable */
	MCUCR |=  (1 << ISC01);      /* Interrupt sense control falling edge */
	MCUCR &= ~(1 << ISC00);      /* Interrupt sense control falling edge */
}

void INT1_CONFIG(void)
{
	GICR  |= (1 << INT1);        /* Interrupt request enable */
	MCUCR |= (1 << ISC11);       /* Interrupt sense control rising edge */
	MCUCR |= (1 << ISC10);       /* Interrupt sense control rising edge */
}

void INT2_CONFIG(void)
{
	GICR   |=  (1 << INT2);      /* Interrupt request enable */
	MCUCSR |=  (1 << ISC2);      /* Interrupt sense control falling edge */
}

int main(void)
{
	SREG |= (1 << 7);            /* Enable global interrupt */
	IO_PINS_CONFIG();
	INT0_CONFIG();
	INT1_CONFIG();
	INT2_CONFIG();
	TIMER1_CTC_CONFIG();

	while(1)
	{
		/* Always Display value on 7-segment*/
		PORTA = (PORTA & 0xC0) | (SEGMENT_1 & 0x3F);
		PORTC = (PORTC & 0xF0) | (SEC_1 & 0x0F);
		_delay_us(1);
		PORTA = (PORTA & 0xC0) | (SEGMENT_2 & 0x3F);
		PORTC = (PORTC & 0xF0) | (SEC_2 & 0x0F);
		_delay_us(1);
		PORTA = (PORTA & 0xC0) | (SEGMENT_3 & 0x3F);
		PORTC = (PORTC & 0xF0) | (MIN_1 & 0x0F);
		_delay_us(1);
		PORTA = (PORTA & 0xC0) | (SEGMENT_4 & 0x3F);
		PORTC = (PORTC & 0xF0) | (MIN_2 & 0x0F);
		_delay_us(1);
		PORTA = (PORTA & 0xC0) | (SEGMENT_5 & 0x3F);
		PORTC = (PORTC & 0xF0) | (HR_1 & 0x0F);
		_delay_us(1);
		PORTA = (PORTA & 0xC0) | (SEGMENT_6 & 0x3F);
		PORTC = (PORTC & 0xF0) | (HR_2 & 0x0F);
		_delay_us(1);
	}
	return 0;
}
